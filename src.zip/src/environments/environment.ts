

export const environment = {
  uri:'https://430d86665cd2.ngrok.io',
  production: false
};

